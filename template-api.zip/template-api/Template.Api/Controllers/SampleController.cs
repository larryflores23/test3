﻿using EastwestBank.Sdk.AspNetCore.Mvc.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Template.Api.Configurations;
using Template.Api.Middleware;
using Template.Api.Models;
using Template.Api.Services;
using Template.Api.Services.Dtos;
using Template.Api.Services.Implementation;

namespace Template.Api.Controllers
{
    [Authorize]
    [ApiVersion("1.0")]
    [Route(RouteConfig.Sample)]
    public class SampleController : Controller
    {
        private readonly ISampleService _sampleService;

        public SampleController(SampleService sampleService)
        {
            _sampleService = sampleService;
        }

        [HttpGet]
        [Route("get-method")]
        public IActionResult Get([FromQuery] SampleGetModel model)
        {
            var result = PolicyConfiguration.CircuitBreakerPolicy.Execute(() => _sampleService.Get(model));

            var response = new ApiResponse<SampleResponse>
            {
                Data = result
            };

            return _sampleService.Validation.IsValid ? Ok(response) : BadRequest(response);
        }

        [HttpPost]
        [Route("post-method")]
        public IActionResult Post([FromBody] SamplePostModel model)
        {
            var result = PolicyConfiguration.CircuitBreakerPolicy.Execute(() => _sampleService.Post(model));

            var response = new ApiResponse<SampleResponse>
            {
                Data = result
            };

            return _sampleService.Validation.IsValid ? Ok(response) : BadRequest(response);
        }
    }
}
