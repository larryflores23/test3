﻿namespace Template.Api.Configurations
{
    public class AppConfig
    {
        public string AllowedHosts { get; set; }

        public AppSettings AppSettings { get; set; }

        public ConnectionStrings ConnectionStrings { get; set; }
    }

    public class ConnectionStrings
    {
        public string Bps { get; set; }
    }

    public class AppSettings
    {
        public string IpAddress { get; set; }
        
        public string DefaultHeader { get; set; }

        public CircuitBreaker CircuitBreaker { get; set; }
    }

    public class CircuitBreaker
    {
        public double FailureThreshold { get; set; }

        public int SamplingDuration { get; set; }

        public int MinimumThroughput { get; set; }

        public int DurationOfBreak { get; set; }
    }
}