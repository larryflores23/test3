﻿namespace Template.Api.Configurations
{
    public class RouteConfig
    {
        public const string Sample = "api/v{version}/sample";
    }
}
