using Autofac;
using Autofac.Extensions.DependencyInjection;
using EastwestBank.Sdk.AspNetCore.Middlewares;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.Identity.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using Template.Api.Configurations;
using Template.Api.Logging;
using Template.Api.Middleware;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSwaggerGen();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddHttpContextAccessor();
builder.Services.AddApiVersioning();
builder.Services.AddCorrelationId();
builder.Services.AddHttpLogging<ApiLoggingProvider>();
builder.Services.AddMicrosoftIdentityWebApiAuthentication(builder.Configuration);

builder.Services
    .Configure<AppConfig>(builder.Configuration)
    .Configure<IISOptions>(options =>
    {
        options.ForwardClientCertificate = false;
    })
    .Configure<ForwardedHeadersOptions>(options =>
    {
        options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
    });

builder.Services.AddControllers(options =>
{
    options.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true;
    options.AllowEmptyInputInBodyModelBinding = true;
});

builder.Services.AddMvc()
    .AddNewtonsoftJson(options =>
    {
        options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
        options.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Utc;
        options.SerializerSettings.MissingMemberHandling = MissingMemberHandling.Ignore;
        options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
        options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
        options.SerializerSettings.DefaultValueHandling = DefaultValueHandling.Include;
        options.SerializerSettings.FloatParseHandling = FloatParseHandling.Double;
        options.SerializerSettings.Formatting = Formatting.None;
    });

builder.Host.UseServiceProviderFactory(new AutofacServiceProviderFactory());

builder.Host.ConfigureContainer<ContainerBuilder>(build =>
{
    build.RegisterAssemblyTypes(Assembly.GetExecutingAssembly())
        .PropertiesAutowired(PropertyWiringOptions.AllowCircularDependencies)
        .AsImplementedInterfaces()
        .AsSelf();

    build.RegisterType<SqlConnection>()
        .As<IDbConnection>()
        .WithParameter("connectionString", builder.Configuration.GetSection("ConnectionStrings:BPS").Value)
        .Keyed<IDbConnection>("BPSConnection");
});

var app = builder.Build();

app.UseCorrelationId(new CorrelationIdOptions { UseGuidForCorrelationId = true });

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseApiSecurity();
app.UsePolicyMiddleware();
app.UseHttpLoggingProvider();
app.UseApiVersioning();
app.UseErrorHandler();
app.MapControllers();

app.Run();
