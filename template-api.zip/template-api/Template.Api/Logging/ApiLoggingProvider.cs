﻿using Template.Api.Data.Entities;
using Template.Api.Data.Repositories.Implementation;
using EastwestBank.Sdk.AspNetCore.Middlewares;
using Newtonsoft.Json;

namespace Template.Api.Logging
{
    public class ApiLoggingProvider : IHttpLoggingProvider
    {
        private readonly IHttpContextAccessor _contextAccessor;
        private readonly ApiContextLogRepository _apiContextLogRepository;

        public ApiLoggingProvider(
            IHttpContextAccessor contextAccessor,
            ApiContextLogRepository apiContextLogRepository)
        {
            _contextAccessor = contextAccessor;
            _apiContextLogRepository = apiContextLogRepository;
        }

        public void Save(HttpLoggingContext context)
        {
            var apiLogEntry = new ApiContextLog
            {
                CorrelationId = context.CorrelationId,
                Machine = context.Machine,
                RequestIpAddress = context.RequestIpAddress,
                RequestContentType = context.RequestContentType,
                RequestContentBody = context.RequestContentBody,
                RequestUri = context.RequestUri,
                RequestMethod = context.RequestMethod,
                RequestHeaders = context.RequestHeaders,
                RequestTimestamp = context.RequestTimestamp,
                ResponseContentType = context.ResponseContentType,
                ResponseContentBody = context.ResponseContentBody,
                ResponseStatusCode = context.ResponseStatusCode,
                ResponseHeaders = context.ResponseHeaders,
                ResponseTimestamp = context.ResponseTimestamp
            };

            _apiContextLogRepository.Insert(apiLogEntry);
        }
    }
}
