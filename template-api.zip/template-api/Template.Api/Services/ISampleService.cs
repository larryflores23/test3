﻿using EastwestBank.Services;
using Template.Api.Models;
using Template.Api.Services.Dtos;

namespace Template.Api.Services
{
    public interface ISampleService: IApplicationService
    {
        SampleResponse Get(SampleGetModel model);

        SampleResponse Post(SamplePostModel model);
    }
}
