﻿namespace Template.Api.Services.Dtos
{
    public class SampleRequest
    {
        public string Data { get; set; }
    }
}
