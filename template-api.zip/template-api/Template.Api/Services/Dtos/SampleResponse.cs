﻿namespace Template.Api.Services.Dtos
{
    public class SampleResponse
    {
        public string Value { get; set; }
    }
}
