﻿using EastwestBank.Services;
using Template.Api.Models;
using Template.Api.Services.Dtos;
using Template.Api.Data.Repositories;
using Template.Api.Data.Repositories.Implementation;

namespace Template.Api.Services.Implementation
{
    public class SampleService : ApplicationService, ISampleService
    {
        private readonly ISettingRepository _settingRepository;

        public SampleService(SettingRepository settingRepository)
        {
            _settingRepository = settingRepository;
        }

        public SampleResponse Get(SampleGetModel model)
        {
            var setting = _settingRepository.GetByName("Code13");

            var response = new SampleResponse()
            {
                Value = setting.Value
            };

            return response;
        }

        public SampleResponse Post(SamplePostModel model)
        {
            var setting = _settingRepository.GetByName("Code12");

            var response = new SampleResponse()
            {
                Value = setting.Value
            };

            return response;
        }
    }
}
