﻿using Template.Api.Configurations;
using Template.Api.Data.Entities;
using Template.Api.Data.Repositories.Implementation;
using Microsoft.Extensions.Options;
using Microsoft.Net.Http.Headers;
using Polly;
using Polly.CircuitBreaker;
using System.Diagnostics;
using System.Net;

namespace Template.Api.Middleware
{
    public class PolicyMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IHttpContextAccessor _contextAccessor;
        private readonly ApplicationLogRepository _applicationLogRepository;

        public PolicyMiddleware(
            RequestDelegate next,
            IHttpContextAccessor contextAccessor,
            ApplicationLogRepository applicationLogRepository,
            IOptions<AppConfig> config)
        {
            _next = next;
            _contextAccessor = contextAccessor;
            _applicationLogRepository = applicationLogRepository;

            PolicyConfiguration.Initialize(config.Value);
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                if (PolicyConfiguration.CircuitBreakerPolicy.CircuitState == CircuitState.Closed ||
                     PolicyConfiguration.CircuitBreakerPolicy.CircuitState == CircuitState.HalfOpen)
                {
                    await _next(context);
                }
                else
                {
                    context.Response.StatusCode = (int)HttpStatusCode.ServiceUnavailable;
                }
            }
            catch (Exception error)
            {
                var applicationName = _contextAccessor.HttpContext.User.Identity.Name ?? "[Unknown]";
                var traceId = _contextAccessor.HttpContext.TraceIdentifier;
                var ipAddress = GetActualIpAddress(_contextAccessor.HttpContext.Connection.RemoteIpAddress.ToString());

                DateTime.TryParse(_contextAccessor.HttpContext.Response.Headers[HeaderNames.LastModified].ToString(), out DateTime executionTime);

                var logEntry = new ApplicationLog
                {
                    Browser = _contextAccessor.HttpContext.Request.Headers[HeaderNames.UserAgent].ToString(),
                    ExecutionTime = executionTime,
                    ExecutionDuration = (DateTime.Now - executionTime).TotalSeconds,
                    ClientName = applicationName,
                    ClientIpAddress = ipAddress
                };

                PopulateException(logEntry, error);

                var stackTrace = new StackTrace(error);

                logEntry.ServiceName = stackTrace.GetFrame(0).GetMethod().DeclaringType.Name;
                logEntry.MethodName = stackTrace.GetFrame(0).GetMethod().Name;
                logEntry.CorrelationId = traceId ?? null;

                _applicationLogRepository.Insert(logEntry);

                throw error;
            }
        }

        private void PopulateException(ApplicationLog log, Exception ex)
        {
            var errorMessage = ex.ToString();
            var endPos = errorMessage.IndexOf("--- End of stack trace");

            log.Exception = endPos > 0 ? errorMessage.Substring(0, endPos) : errorMessage;

            if (log.Exception.Length > 4000)
            {
                log.Exception = log.Exception.Substring(0, 4000);
            }
        }

        private string GetActualIpAddress(string hostNameAddress)
        {
            return IsLocalHost(hostNameAddress) ? "127.0.0.1" : hostNameAddress;
        }

        private bool IsLocalHost(string hostNameAddress)
        {
            try
            {
                var hostIPs = Dns.GetHostAddresses(hostNameAddress);
                var localIPs = Dns.GetHostAddresses(Dns.GetHostName());

                return hostIPs.Any(hostIP => IPAddress.IsLoopback(hostIP) || localIPs.Contains(hostIP));
            }
            catch
            {
                return false;
            }
        }
    }

    public static class PolicyMiddlewareExtensions
    {
        public static IApplicationBuilder UsePolicyMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<PolicyMiddleware>();
        }
    }

    public static class PolicyConfiguration
    {
        private static Action<Exception, TimeSpan> OnBreak => OnCircuitBreakAction;
        private static Action OnReset => OnCircuitResetAction;

        //Set default value
        private static double FailureThreshold = 0.5;
        private static int MinimumThroughput = 100;
        private static int SamplingDuration = 60;
        private static int DurationOfBreak = 10;

        private static void OnCircuitBreakAction(Exception ex, TimeSpan timeSpan)
        {
            Console.WriteLine("Circuit Broken");

            throw ex;
        }

        private static void OnCircuitResetAction()
        {
            Console.WriteLine("Circuit Reset");
        }

        public static void Initialize(AppConfig config)
        {
            FailureThreshold = config.AppSettings.CircuitBreaker.FailureThreshold;
            MinimumThroughput = config.AppSettings.CircuitBreaker.SamplingDuration;
            SamplingDuration = config.AppSettings.CircuitBreaker.MinimumThroughput;
            DurationOfBreak = config.AppSettings.CircuitBreaker.DurationOfBreak;
        }

        public static readonly CircuitBreakerPolicy CircuitBreakerPolicy = Policy
          .Handle<Exception>()
          .AdvancedCircuitBreaker(
              failureThreshold: FailureThreshold,
              samplingDuration: TimeSpan.FromSeconds(SamplingDuration),
              minimumThroughput: MinimumThroughput,
              durationOfBreak: TimeSpan.FromSeconds(DurationOfBreak),
              OnBreak,
              OnReset);
    }
}
