﻿using Microsoft.Net.Http.Headers;
using Template.Api.Data.Entities;
using Template.Api.Data.Repositories.Implementation;
using System.Diagnostics;
using System.Net;
using Newtonsoft.Json;

namespace Template.Api.Middleware
{
    public class ErrorHandlerMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IHttpContextAccessor _contextAccessor;
        private readonly ApplicationLogRepository _applicationLogRepository;

        public ErrorHandlerMiddleware(
            RequestDelegate next,
            IHttpContextAccessor contextAccessor,
            ApplicationLogRepository applicationLogRepository)
        {
            _next = next;
            _contextAccessor = contextAccessor;
            _applicationLogRepository = applicationLogRepository;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                if (string.IsNullOrEmpty(_contextAccessor.HttpContext.Response.Headers.LastModified))
                {
                    _contextAccessor.HttpContext.Response.Headers.Add(HeaderNames.LastModified, DateTime.Now.ToString());
                }
                else
                {
                    _contextAccessor.HttpContext.Response.Headers.LastModified =
                        DateTime.Parse(_contextAccessor.HttpContext.Response.Headers.LastModified).ToLocalTime().ToString();
                }

                await _next(context);
            }
            catch (Exception error)
            {
                var applicationName = _contextAccessor.HttpContext.User.Identity.Name ?? "[Unknown]";
                var traceId = _contextAccessor.HttpContext.TraceIdentifier;
                var ipAddress = GetActualIpAddress(_contextAccessor.HttpContext.Connection.RemoteIpAddress.ToString());

                DateTime.TryParse(_contextAccessor.HttpContext.Response.Headers[HeaderNames.LastModified].ToString(), out DateTime executionTime);

                var logEntry = new ApplicationLog
                {
                    Browser = _contextAccessor.HttpContext.Request.Headers[HeaderNames.UserAgent].ToString(),
                    ExecutionTime = executionTime,
                    ExecutionDuration = (DateTime.Now - executionTime).TotalSeconds,
                    ClientName = applicationName,
                    ClientIpAddress = ipAddress
                };

                PopulateException(logEntry, error);

                var stackTrace = new StackTrace(error);

                logEntry.ServiceName = stackTrace.GetFrame(0).GetMethod().DeclaringType.Name;
                logEntry.MethodName = stackTrace.GetFrame(0).GetMethod().Name;
                logEntry.CorrelationId = traceId ?? null;

                _applicationLogRepository.Insert(logEntry);

                throw error;
            }

        }

        private void PopulateException(ApplicationLog log, Exception ex)
        {
            var errorMessage = ex.ToString();
            var endPos = errorMessage.IndexOf("--- End of stack trace");

            log.Exception = endPos > 0 ? errorMessage.Substring(0, endPos) : errorMessage;

            if (log.Exception.Length > 4000)
            {
                log.Exception = log.Exception.Substring(0, 4000);
            }
        }

        private string GetActualIpAddress(string hostNameAddress)
        {
            return IsLocalHost(hostNameAddress) ? "127.0.0.1" : hostNameAddress;
        }

        private bool IsLocalHost(string hostNameAddress)
        {
            try
            {
                var hostIPs = Dns.GetHostAddresses(hostNameAddress);
                var localIPs = Dns.GetHostAddresses(Dns.GetHostName());

                return hostIPs.Any(hostIP => IPAddress.IsLoopback(hostIP) || localIPs.Contains(hostIP));
            }
            catch
            {
                return false;
            }
        }
    }

    public static class ErrorHandlerMiddlewareExtensions
    {
        public static IApplicationBuilder UseErrorHandler(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ErrorHandlerMiddleware>();
        }
    }
}