﻿
namespace Template.Api.Middleware
{
    public static class SecurityMiddlewareExtensions
    {
        public static IApplicationBuilder UseApiSecurity(this IApplicationBuilder builder)
        {
            return builder
                .UseAuthentication()
                .UseAuthorization()
                .UseSecurityHeaders()
                .UseDisableResponseCaching()
                .UseHttpsRedirection();
        }
    }
}
