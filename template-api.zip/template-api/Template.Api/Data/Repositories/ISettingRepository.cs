﻿using EastwestBank.Data.Repositories;
using Template.Api.Data.Entities;

namespace Template.Api.Data.Repositories
{
    public interface ISettingRepository : IRepository<Setting>
    {
        Setting GetByName(string name);

        IEnumerable<Setting> GetByGroup(string group);

        IEnumerable<Setting> GetAll();
    }
}
