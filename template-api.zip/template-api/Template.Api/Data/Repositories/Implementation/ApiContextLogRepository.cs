﻿using Dapper;
using EastwestBank.Data.Repositories;
using System.Data;
using Template.Api.Data.Entities;

namespace Template.Api.Data.Repositories.Implementation
{
    public class ApiContextLogRepository : DapperRepository<ApiContextLog>
    {
        public ApiContextLogRepository(IDbConnection connection) : base(connection)
        {
        }

        public override ApiContextLog Insert(ApiContextLog entity)
        {
            var sql =
                 @"INSERT INTO [ApiContextLog]
                       ([CorrelationId]
                       ,[Machine]
                       ,[RequestIpAddress]
                       ,[RequestContentType]
                       ,[RequestContentBody]
                       ,[RequestUri]
                       ,[RequestMethod]
                       ,[RequestHeaders]
                       ,[RequestTimestamp]
                       ,[ResponseContentType]
                       ,[ResponseContentBody]
                       ,[ResponseStatusCode]
                       ,[ResponseHeaders]
                       ,[ResponseTimestamp])
                 VALUES
                       (@CorrelationId
                       ,@Machine
                       ,@RequestIpAddress
                       ,@RequestContentType
                       ,@RequestContentBody
                       ,@RequestUri
                       ,@RequestMethod
                       ,@RequestHeaders
                       ,@RequestTimestamp
                       ,@ResponseContentType
                       ,@ResponseContentBody
                       ,@ResponseStatusCode
                       ,@ResponseHeaders
                       ,@ResponseTimestamp)";

            var parameter = new
            {
                CorrelationId = entity.CorrelationId,
                Machine = entity.Machine,
                RequestIpAddress = entity.RequestIpAddress,
                RequestContentType = entity.RequestContentType,
                RequestContentBody = entity.RequestContentBody,
                RequestUri = entity.RequestUri,
                RequestMethod = entity.RequestMethod,
                RequestHeaders = entity.RequestHeaders,
                RequestTimestamp = entity.RequestTimestamp,
                ResponseContentType = entity.ResponseContentType,
                ResponseContentBody = entity.ResponseContentBody,
                ResponseStatusCode = entity.ResponseStatusCode,
                ResponseHeaders = entity.ResponseHeaders,
                ResponseTimestamp = entity.ResponseTimestamp
            };

            var result = Connection.Execute(sql, parameter);

            return result > 0 ? entity : null;
        }
    }
}
