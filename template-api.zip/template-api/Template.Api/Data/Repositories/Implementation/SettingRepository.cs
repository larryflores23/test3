﻿using Dapper;
using EastwestBank.Data.Repositories;
using Microsoft.Extensions.Options;
using System.Data;
using Template.Api.Configurations;
using Template.Api.Data.Entities;

namespace Template.Api.Data.Repositories.Implementation
{
    public class SettingRepository : DapperRepository<Setting> , ISettingRepository
    {
        private readonly AppConfig _config;

        public SettingRepository(
            IOptions<AppConfig> config, 
            IDbConnection connection) :base(connection)
        {
            _config = config.Value;
        }

        public Setting GetByName(string name)
        {
            var sql = @"SELECT * FROM [setting] WHERE [name] = @Name";

            var setting = Connection.QueryFirstOrDefault<Setting>(sql, new { Name = name });

            return setting;
        }

        public IEnumerable<Setting> GetByGroup(string group)
        {
            var sql = @"SELECT * FROM [setting] WHERE [group] = @Group";

            return Connection.Query<Setting>(sql, new { Group = group });
        }

        public override IEnumerable<Setting> GetAll()
        {
            var sql = @"SELECT * FROM [setting]";

            return Connection.Query<Setting>(sql);
        }
    }
}
