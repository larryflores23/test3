﻿using Dapper;
using EastwestBank.Data.Repositories;
using System.Data;
using Template.Api.Data.Entities;

namespace Template.Api.Data.Repositories.Implementation
{
    public class ApplicationLogRepository : DapperRepository<ApplicationLog>
    {
        public ApplicationLogRepository(IDbConnection connection) : base(connection)
        {
        }

        public override ApplicationLog Insert(ApplicationLog entity)
        {
            var sql =
                @"INSERT INTO [ApplicationLog]
                       ([CorrelationId]
                       ,[ExecutionTime]
                       ,[ServiceName]
                       ,[MethodName]
                       ,[ClientName]
                       ,[ClientIpAddress]
                       ,[Browser]
                       ,[Exception])
                 VALUES
                       (@CorrelationId
                       ,@ExecutionTime
                       ,@ServiceName
                       ,@MethodName
                       ,@ClientName
                       ,@ClientIpAddress
                       ,@Browser
                       ,@Exception)";

            var parameter = new
            {
                CorrelationId = entity.CorrelationId,
                ExecutionTime = entity.ExecutionTime,
                ServiceName = entity.ServiceName,
                MethodName = entity.MethodName,
                ClientName = entity.ClientName,
                ClientIpAddress = entity.ClientIpAddress,
                Browser = entity.Browser,
                Exception = entity.Exception
            };

            var result = Connection.Execute(sql, parameter);

            return result > 0 ? entity : null;
        }
    }
}
