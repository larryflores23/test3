﻿using EastwestBank.Data.Entities;
using EastwestBank.Data.Entities.Auditing;

namespace Template.Api.Data.Entities
{
    public class ApplicationLog : Entity
    {
        public string CorrelationId { get; set; }

        public DateTime ExecutionTime { get; set; }

        public double ExecutionDuration { get; set; }

        public string ServiceName { get; set; }

        public string MethodName { get; set; }

        public string ClientName { get; set; }

        public string ClientIpAddress { get; set; }

        public string Browser { get; set; }

        public string Exception { get; set; }
    }
}
