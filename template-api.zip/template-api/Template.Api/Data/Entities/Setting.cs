﻿using EastwestBank.Data.Entities;

namespace Template.Api.Data.Entities
{
    public class Setting : Entity
    {
        [ConfigurationKeyName("ID")]
        public override int Id { get => base.Id; set => base.Id = value; }

        public string Name { get; set; }

        public string Description { get; set; }

        public string Value { get; set; }

        public string Group { get; set; }

        public int Type { get; set; }
    }
}
