﻿namespace Template.Api.Models
{
    public class SampleGetModel
    {
        public string Name { get; set; }

        public string Description { get; set; }
    }
}
