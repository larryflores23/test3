﻿namespace Template.Api.Models
{
    public class SamplePostModel
    {
        public string Name { get; set; }

        public string Description { get; set; }
    }
}
